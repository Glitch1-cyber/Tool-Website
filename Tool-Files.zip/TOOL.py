import tkinter as tk 
import random
import time
import hashlib
import webbrowser



def github_link():
    webbrowser.open('https://github.com/Glitch1-cyber')

# First site

first_site = tk.Tk()
first_site.geometry('1000x800')
first_site.configure(bg='black')

Head = tk.Label(first_site, text='Welcome to Fake-identity Generator', bg='black', fg='red', font=('Arial', 24))
Head.pack(pady=20)


warn = tk.Label(first_site, text='Warning this tool is only for educational purposes only! dont use for illegal things', bg='black', fg='red', font=('Arial', 16))
warn.pack(pady=20)

Info = tk.Label(first_site, text='If you get an identity that is Under 25 years old, you will not get an life story', bg='black', fg='red', font=('Arial', 16))
Info.place(y=270, x=100)
def start_tool():
    first_site.destroy()





btn_start = tk.Button(first_site, text='Start', bg='#333333', fg='red', font=('Arial', 24), command=start_tool, cursor='hand2')
btn_start.pack(pady=300)





first_site.mainloop()


# Main Tool

root = tk.Tk()
root.attributes('-fullscreen', True)
root.configure(bg="#000000")
root.title('Fake Identity Generator')











Header = tk.Label(root, text='Fake identity Generator', bg="#000000", fg='red',font=('Arial', 24))
Header.pack(pady=20)

warning2 = tk.Label(root, text='If you need an image you can find images of people in the img directory ', bg="#000000", fg='red',font=('Arial', 16))
warning2.pack()


Male_Name = [
    "Lukas Weber", "Leon Koch", "Paul Richter", "Tim Schäfer", "Felix Wolf",
    "Jonas Meier", "Max Neumann", "Elias Zimmermann", "Noah Hartmann", "Nico König",
    "Matteo Esposito", "Luca Marino", "Alessandro Lombardi", "Francesco Ferrara", "Davide Costa",
    "Marco Vitale", "Tommaso Fontana", "Giorgio Leone", "Andrea Benedetti", "Riccardo De Santis",
    "Lucas Martin", "Théo Petit", "Hugo Robert", "Julien Dubois", "Nathan Leroy",
    "Antoine Caron", "Maxime Blanc", "Gabriel François", "Romain Girard", "Louis Fontaine",
    "Alejandro Ruiz", "Javier Hernández", "Pablo Jiménez", "Diego Romero", "Sergio Navarro",
    "David Ramos", "Carlos Castro", "Luis Iglesias", "Miguel Domínguez", "Juan Ortiz",
    "James Johnson", "William Smith", "Benjamin Brown", "Michael Williams", "Ethan Davis",
    "Daniel Miller", "Alexander Wilson", "Henry Moore", "Jack Taylor", "Samuel Thomas",
    "Ahmed Al-Farsi", "Omar Hassan", "Yusuf Kadir", "Ali Jafari", "Rami Youssef",
    "Rajesh Patel", "Amit Sharma", "Sandeep Kumar", "Vikram Singh", "Arjun Verma",
    "Carlos Peña", "Diego García", "Fernando Rodríguez", "José Luis Torres", "Manuel Sánchez",
    "Marek Nowak", "Piotr Kowalski", "Jakub Wiśniewski", "Andrzej Zieliński", "Tomasz Kowalczyk",
    "Liam O'Connor", "Sean Murphy", "Dylan Byrne", "Patrick O'Brien", "Conor Walsh",
    "Kwame Mensah", "Kofi Boateng", "Kwabena Antwi", "Ebo Kwarteng", "Kojo Adom",
    "Jin Lee", "Takeshi Suzuki", "Yuki Tanaka", "Hiroshi Nakamura", "Ryoji Yamamoto",
    "Nikhil Gupta", "Aakash Shah", "Arvind Rao", "Suresh Babu", "Karthik Reddy",
    "Ali Abbas", "Ibrahim Khan", "Nadir Akram", "Zayd Hussain", "Omar Syed",
    "Tariq Al-Mansouri", "Zain Malik", "Khalid Al-Saud", "Abdul Rahman", "Mohammed Saeed",
    "Ahmed Ali", "Sami Al-Hassan", "Faisal Jamil", "Hassan Rahim", "Rashid Kamil",
    "Carlos Silva", "Ricardo Gonzalez", "Miguel Ángel Díaz", "José Martínez", "Juan Carlos Ruiz",
    "Nassim Ben Ali", "Farid Othmani", "Youssef Elbaz", "Zaki Bouzid", "Omar Mekki",
    "Ibrahim Abdi", "Mohamed Noor", "Musa Yusuf", "Mahir Yilmaz", "Serkan Demir",
    "Yuval Cohen", "Erez Ben David", "Moshe Levi", "Yaakov Friedman", "Uriel Barak",
    "Teo Jovanovic", "Nikola Markovic", "Luka Petrovic", "Miloš Ivanovic", "Dusan Ristic",
    "Zoran Jovic", "Mateo Pavić", "Josip Kovačić", "Simeon Dimitrov", "Nikolai Petrov",
    "Sultan Al-Zahrani", "Fahad Al-Fahad", "Majid Al-Shammari", "Khaled Al-Mohammed", "Salman Jaber",
    "Dmitry Ivanov", "Andrei Kuznetsov", "Kirill Popov", "Vladislav Smirnov", "Alexei Fedorov",
    "Javier Martínez", "Ricardo González", "Andrés Rodríguez", "Joaquín Pérez", "Francisco Jiménez",
    "Marco Silva", "Tiago Costa", "João Mendes", "Carlos Eduardo", "Bruno Santos"
]




Female_Names = [
    "Anna Müller", "Lea Schneider", "Julia Becker", "Emma Fischer", "Lara Wagner",
    "Giulia Rossi", "Sofia Bianchi", "Chiara Romano", "Alessia Conti", "Martina Ricci",
    "Camille Dupont", "Léa Moreau", "Chloé Laurent", "Manon Bernard", "Inès Roux",
    "María García", "Carmen López", "Ana Fernández", "Laura Martínez", "Lucía Pérez",
    "Emily Johnson", "Olivia Smith", "Ava Williams", "Isabella Brown", "Mia Jones",
    "Harper Davis", "Charlotte Wilson", "Amelia Miller", "Evelyn Anderson", "Abigail Taylor",
    "Sakura Tanaka", "Yui Sato", "Aiko Nakamura", "Mei Kobayashi", "Hana Takahashi",
    "Rina Yamamoto", "Naomi Suzuki", "Haruka Watanabe", "Ayaka Ito", "Emi Matsumoto",
    "Sophia Hofmann", "Marie Schulz", "Amelie Keller", "Clara Vogel", "Johanna Braun",
    "Valentina Gallo", "Elisa Moretti", "Francesca Greco", "Aurora Rinaldi", "Caterina De Luca",
    "Amina Al-Farsi", "Layla Hassan", "Fatima Ali", "Mariam Youssef", "Zahra Rahimi",
    "Rania Khalil", "Nadia Mohamed", "Samira Ben Ali", "Khadija Jafari", "Amira Osman",
    "Ananya Patel", "Priya Sharma", "Meera Desai", "Rhea Gupta", "Isha Singh",
    "Jaspreet Kaur", "Ayesha Khan", "Sana Ahmed", "Zara Malik", "Nikita Rao",
    "Isabella Costa", "Giovanna Ferraro", "Francesca Moretti", "Sofia Di Stefano", "Paola Ricci",
    "Ana Sofia Pérez", "Marina García", "Raquel Ruiz", "Lucía Fernández", "Eva Martínez",
    "Margarita Rodríguez", "Luna Sánchez", "Valeria López", "Gabriela Castro", "Carla Silva",
    "Zoé Dubois", "Julie Lefevre", "Elise Girard", "Maëlle Lefevre", "Claire Dupuis",
    "Amélie Gauthier", "Nathalie Moreau", "Lucie Bernard", "Sophie Richard", "Céline Robert",
    "Irene Pérez", "Carmen Castillo", "Patricia Jiménez", "Monica González", "Teresa López",
    "Juliana Silva", "Beatriz Castro", "Adriana Ruiz", "Renata Gómez", "Marcela López",
    "Sinead O'Connor", "Maeve Lynch", "Clodagh Murphy", "Aoife Byrne", "Roisín Kelly",
    "Sinead Kelly", "Fiona Gallagher", "Siobhan Walsh", "Aoibheann Ní Mhurchú", "Éabha Ní Chinnéide",
    "Leila Al-Mansouri", "Maya Al-Hassan", "Nour Jaber", "Nadia Al-Hamdan", "Lina Al-Sabah",
    "Fatimah Saeed", "Muna Al-Fahad", "Shirin Reza", "Layla Mossa", "Salma Ali",
    "Yasmin Jafari", "Maha Sayed", "Alaa Mohamed", "Nour Al-Qassimi", "Dina Bakr",
    "Olga Ivanova", "Anastasia Petrov", "Ekaterina Smirnova", "Daria Volnova", "Viktoria Sokolova",
    "Natalia Kuznetsova", "Polina Orlova", "Margarita Baranova", "Irina Volkov", "Elena Pavlova",
    "Zhenzhen Li", "Mei Ling Wang", "Ying Xu", "Hui Zhang", "Qing Wei"
]




hobbies = [
    "Brewing different types of coffee and experimenting with methods.",
    "Running marathons and participating in charity races.",
    "Stargazing and learning about constellations and planets.",
    "Hiking in nature reserves and national parks.",
    "Photography, focusing on portraits and landscape shots.",
    "Gardening, growing herbs, flowers, and vegetables.",
    "Reading fiction, non-fiction, and exploring new genres.",
    "Traveling to new places and learning about different cultures.",
    "Cycling through scenic routes or around the city.",
    "Painting and experimenting with watercolor or oil paints.",
    "Sketching landscapes, people, and still life.",
    "Cooking new recipes and exploring different cuisines.",
    "Baking bread, cakes, and experimenting with pastries.",
    "Swimming in lakes, oceans, or at the local pool.",
    "Practicing yoga for flexibility and mental clarity.",
    "Dancing to different styles like salsa, hip-hop, or contemporary.",
    "Singing in a choir or practicing solo performances.",
    "Playing guitar and learning new songs.",
    "Learning piano and playing classical or modern pieces.",
    "Playing chess and improving strategic thinking.",
    "Creating pottery and sculpting with clay.",
    "Writing short stories or keeping a personal blog.",
    "Crafting jewelry or making other handmade items.",
    "Bird watching and identifying species in local parks.",
    "Fishing in rivers, lakes, or off the coast.",
    "Camping under the stars and enjoying nature.",
    "Rock climbing in indoor gyms or outdoor cliffs.",
    "Knitting and creating scarves, hats, or blankets.",
    "Journaling to reflect on the day's thoughts or goals.",
    "Learning a new language and practicing with native speakers.",
    "Woodworking and building furniture or decor items.",
    "Meditating for relaxation and stress relief.",
    "Playing board games and learning new strategies.",
    "Wine tasting and exploring the world of different varieties.",
    "Horseback riding in the countryside or on trails.",
    "Ice skating and practicing spins and jumps.",
    "Snowboarding in the winter or learning new techniques.",
    "Origami and creating paper art with intricate designs."
]

life_stories_man = [
    "After years of focusing on work, he realized he had missed out on quality time with his family. He made changes to spend more weekends with them, and now they have a stronger bond than ever.",
    "Faced a difficult time in his marriage, but instead of giving up, he and his partner decided to go to therapy. It wasn't easy, but their relationship became more open and supportive as a result.",
    "Raised his child as a single parent, juggling work and home life. Though the challenges were immense, seeing his child grow into a kind and resilient person made it all worth it.",
    "Lost contact with his sibling after a falling out years ago. Eventually reached out, and through honest conversation, they healed their relationship and now share a stronger connection than before.",
    "Had to move away for work, leaving his family behind. Over time, he realized how important family support was, and worked to return home, not just physically, but emotionally as well.",
    "Was struggling to be present for his children while working long hours. He started a small tradition of family nights, and it transformed how he balanced his career and family life.",
    "Grew up with a distant father. After becoming a parent himself, he realized how much he had missed, and vowed to be a more engaged father, making every effort to show up for his kids.",
    "His father was diagnosed with a serious illness, and he had to step up to care for him. It was a tough, emotional journey, but it deepened their relationship in ways he never imagined.",
    "Lost his partner unexpectedly and struggled with grief. Over time, he found healing by focusing on his children and honoring his partner's memory through shared stories and experiences.",
    "Was constantly busy with work, but when his child had a school performance, he dropped everything to be there. That small moment made him realize that being present is what truly matters.",
    "He spent most of his adult life prioritizing his career, but after a health scare, he decided to make fitness and mental well-being a priority, finding balance between success and self-care.",
    "After years of emotional distance, he reconnected with his estranged father. Though it was difficult, they learned to communicate openly, and it healed old wounds.",
    "Struggled with his self-image for years but found peace when he started practicing mindfulness and embracing who he truly was. He now mentors other men to break free from societal pressures and be their authentic selves.",
    "At 45, he decided to change careers and follow his passion for teaching. It was a huge risk, but the joy and fulfillment he found in his new role made the leap worthwhile.",
    "Faced a major financial setback that almost ruined him. However, by leaning on his family and finding creative solutions, he bounced back and is now more financially secure than ever.",
    "Was afraid of commitment due to past relationships, but after meeting the right person, he learned to open up and embrace love, creating a deep and lasting partnership.",
    "Raised his children in a small town and often worried about their futures. When they both moved to big cities, he realized he had instilled in them the confidence to thrive independently.",
    "After his divorce, he struggled with loneliness and self-doubt. Over time, he focused on self-improvement, took up new hobbies, and built a fulfilling life outside of a relationship.",
    "He was always told that being sensitive was a weakness. But when he embraced his emotions, he found it made him a better friend, partner, and father.",
    "Faced a crossroads in his career and nearly walked away from a promising job offer to follow his true passion for music. He took the leap, and now he has a thriving side career as a musician.",
    "Had an intense rivalry with a colleague for years, but after a heart-to-heart conversation, they learned to collaborate and respect each other, turning their rivalry into a productive partnership.",
    "After years of not knowing how to talk about his feelings, he finally sought therapy. It was a life-changing decision that allowed him to improve his relationships and develop better emotional awareness.",
    "Became a mentor to a young man who had faced many challenges. Their relationship grew into a deep friendship, and he found purpose in guiding someone else through difficult times.",
    "When he lost his job, he felt like everything was falling apart. But after some soul-searching, he pursued a long-held dream of becoming an entrepreneur, and his small business is now thriving.",
    "Grew up with a father who never expressed love or affection. As a result, he made a conscious decision to be more emotionally available for his own children, breaking the cycle of emotional distance.",
    "Had a strained relationship with his mother for many years, but after becoming a father, he realized how much she had sacrificed for him. They slowly rebuilt their bond and grew closer in his adulthood.",
    "Always had an interest in woodworking but never took it seriously until he retired. Now, it’s become his favorite hobby, and he even sells some of his work, finding both joy and fulfillment in the craft.",
    "Faced the pressure of being the primary breadwinner in his family, but eventually realized the importance of balance. He started taking more time for hobbies and spending quality moments with his family.",
    "He struggled with feelings of inadequacy after failing in a few relationships. But after personal growth and reflection, he learned to embrace vulnerability and found a partner who loved him for who he was.",
    "Was raised to believe that men should always be strong and stoic. After years of battling internal struggles, he realized that asking for help was not a sign of weakness, and it helped him grow stronger.",
    "Decided to take a year off from work to travel the world. This sabbatical gave him a new perspective on life and reinvigorated his passion for his career once he returned.",
    "After years of feeling disconnected from his own culture, he decided to explore his heritage. This journey not only gave him a deeper understanding of his roots but also brought him closer to his family.",
    "Experienced a difficult period in his life where he felt like a failure. But through personal development and a renewed sense of purpose, he rebuilt his life and started a new chapter of success.",
    "After losing a close friend to illness, he realized how precious time with loved ones truly is. He now makes an effort to call his friends regularly and cherish the moments they have together.",
    "Was always focused on his career and put his personal life on hold. But when he saw how much time he had missed with his own children, he decided to step back and create more family memories.",
    "Had a complicated relationship with his father, but after the old man fell ill, he spent time caring for him. Their time together brought healing and allowed them to have meaningful conversations before it was too late.",
    "Started a podcast about mental health awareness for men. His personal struggles with anxiety and depression became a source of strength for others, and he’s now an advocate for better mental health care.",
    "Experienced a significant setback in his business, but instead of quitting, he learned valuable lessons that helped him refine his approach. Now, his company is more successful than before.",
    "Grew up in a tough neighborhood and was often told that he wouldn’t make it out. Today, he’s a successful lawyer, using his platform to mentor young men and help them find opportunities for success.",
    "Dealt with a major life change when he had to care for his elderly parents. It was emotionally taxing, but it taught him the true meaning of unconditional love and sacrifice.",
    "Lost a great deal of weight after years of struggling with obesity. His journey to health was challenging, but he now feels stronger and more confident than ever, and shares his story to inspire others.",
    "After the birth of his second child, he realized he wasn’t as involved in his first child’s life as he wanted to be. He made a conscious effort to be more present and engaged, strengthening their bond.",
    "Had a difficult relationship with his mother growing up but, after becoming a parent, found a deep appreciation for all she did. They’ve since become close and share meaningful moments together.",
    "He always dreamed of writing a book, but self-doubt held him back. After a life-changing trip, he returned and began writing. His first novel was published to great success, inspiring others to chase their own dreams.",
    "Had to learn to let go of control when he became a father. His desire to protect and guide his children evolved into a deeper understanding of the importance of letting them learn from their own experiences.",
    "Struggled with being a perfectionist in his career. Once he learned to embrace failure as part of the growth process, he became more confident and innovative in his approach to work.",
    "He was always the strong, silent type in his relationships, but he eventually learned that emotional vulnerability strengthened his bond with his partner. Now, their relationship is deeper than ever.",
    "Spent years trying to fit into society's definition of success, only to realize that true happiness lay in doing what he loved. He transitioned into a career in the arts and now feels more fulfilled.",
    "After losing his childhood friend, he was devastated but took solace in the memories they shared. He now celebrates their friendship annually, keeping their bond alive in his heart.",
    "As a young man, he dreamed of being a professional athlete. While that didn’t happen, he channeled his love for sports into coaching, and now he helps young athletes develop both their skills and character.",
    "He was reluctant to ask for help with his mental health, but once he did, it changed everything. Seeking therapy helped him break through years of emotional barriers and led to a deeper sense of self-acceptance.",
    "Decided to adopt after struggling with infertility. His journey to fatherhood through adoption taught him about patience, resilience, and the deep bond that can form through love, not biology.",
    "After working in a job that made him unhappy for years, he finally quit and became a freelance writer. The uncertainty was scary, but it led to more creative freedom and a fulfilling career.",
    "After his father’s sudden death, he was forced to grow up quickly. The experience taught him about life’s fleeting nature and motivated him to live each day with purpose and intentionality.",
    "After losing his job, he struggled to stay positive. But after reconnecting with old friends and finding new passions, he turned his life around and found a new career that better suited his values and aspirations.",
    "He used to believe that being a man meant never showing weakness. But after becoming a father, he realized that showing vulnerability was a strength, and it made him a better partner and father.",
    "He had been carrying emotional baggage for years but didn’t realize it until he entered therapy. The process was painful, but ultimately it freed him to experience deeper, more meaningful relationships."
]

life_stories_women = [
    "After years of neglecting her personal life for her career, she realized how much she missed spending time with her family. Now, she makes sure to create moments with loved ones, strengthening their bond.",
    "Faced a difficult chapter in her marriage, but instead of walking away, she chose to open up and communicate more. After a lot of work, she and her partner found a deeper understanding and connection.",
    "Raised her children as a single mother, balancing work and home life. Despite the exhaustion, her kids grew up to be compassionate, driven individuals, and she felt proud of what they'd overcome together.",
    "Had a falling out with her sister that lasted years. Finally, she reached out to apologize, and through their conversations, they healed their relationship and built a stronger sisterly bond.",
    "Moved to a new city for a job, leaving her family behind. Over time, she realized how important family support was and made the decision to go back home, both physically and emotionally.",
    "Struggled to find a balance between work and family life. One day, she made the conscious decision to reduce her hours and spend more time with her children. That shift brought a deeper sense of fulfillment.",
    "Grew up with an emotionally distant mother. When she became a parent herself, she understood the impact of that distance and committed to being emotionally available for her own children.",
    "When her mother was diagnosed with cancer, she became her caregiver. It was a painful and rewarding journey that deepened her understanding of love, sacrifice, and family.",
    "Lost her partner unexpectedly, and the grief was overwhelming. However, focusing on her children and honoring her partner's memory through their shared memories brought her a sense of peace over time.",
    "Was often consumed by her job but made a commitment to be there for her child's school events. That simple decision of being present for her family transformed her perspective on what really matters.",
    "After battling with self-doubt for years, she decided to take a leap of faith and start her own business. The road wasn't easy, but through perseverance, she built something meaningful and empowering for herself and others.",
    "She faced an unexpected health diagnosis that changed everything. Rather than focusing on the fear, she turned it into a passion for health advocacy, helping others with similar struggles find support and strength.",
    "Having grown up in a conservative family, she struggled to express her true self. As an adult, she embraced her identity and became an advocate for LGBTQ+ rights, inspiring others to live authentically.",
    "After a difficult divorce, she found herself lost for a while. It took time, but she gradually rediscovered her passions, picked up old hobbies, and learned to enjoy her own company again. Now, she's stronger and more confident than ever.",
    "Moved to a foreign country to pursue her dreams, despite language barriers and cultural differences. Over time, she built a new life for herself and developed deep friendships, proving to herself that change can be a beautiful adventure.",
    "Faced with the challenge of raising a child with special needs, she found herself learning new levels of patience, understanding, and strength. The experience helped her grow into a fierce advocate for disability rights.",
    "Was always seen as the quiet one in the family, but after a period of introspection, she decided to finally speak up about her dreams and desires. Her newfound voice transformed her relationships and brought a deeper connection with those she loved.",
    "When she became a mother, she had to let go of her independent lifestyle and adjust to the new role. But in the process, she found new strength in nurturing and guiding her children, realizing the power of unconditional love.",
    "Spent years in a toxic friendship, unsure of how to break free. Finally, she found the courage to walk away, prioritizing her mental and emotional well-being. It was a painful but necessary decision for her personal growth.",
    "Always dreamed of traveling the world but put it on hold due to responsibilities. At 40, she decided it was now or never and embarked on a solo adventure, discovering new places and herself along the way.",
    "She grew up in a small town where she was told she'd never amount to much. Determined to prove them wrong, she moved to a big city, earned her degree, and became a successful lawyer, inspiring others from her hometown.",
    "She struggled with postpartum depression after the birth of her second child. Through therapy, support groups, and time, she found healing and became a passionate advocate for mental health awareness for mothers.",
    "After a miscarriage, she faced an emotional rollercoaster, but her resilience kept her going. Years later, she became a mother to a beautiful child through adoption, finding peace in the unexpected path her life took.",
    "Her father was her role model growing up. When he passed away unexpectedly, she found herself lost, but her father's legacy of hard work and kindness inspired her to keep moving forward, making him proud in every way she could.",
    "Always passionate about education, she decided to go back to school in her 30s to become a teacher. It was a challenging journey, but her love for the profession and her students made every hardship worth it.",
    "She spent years hiding her struggles with anxiety, too afraid to speak up. Eventually, she opened up to her friends and family, and through their support, she found strength in vulnerability and was able to manage her mental health.",
    "After years of following societal expectations, she finally decided to break free from the mold and pursue a career in the arts. Today, she's a renowned artist who inspires others to chase their creative dreams.",
    "Her childhood dream was always to become a professional dancer, but after a knee injury, she had to let go of that vision. Now, she teaches dance to underprivileged youth, making sure to inspire others to keep dancing in their own way.",
    "When her best friend was diagnosed with depression, she didn't know how to help. But through learning about mental health and supporting her friend, she became an advocate for breaking the stigma around mental illness.",
    "She grew up in a family where emotions were never discussed, but when she became a mother, she realized how important it was to talk about feelings openly. Now, she encourages her children to express themselves honestly and without fear.",
    "As a woman in a male-dominated industry, she faced constant doubt and skepticism. But instead of shrinking, she stood her ground, became a leader in her field, and now mentors young women who face similar challenges.",
    "Having experienced body shaming in her youth, she spent years trying to conform to beauty standards. It wasn’t until she started practicing self-love that she finally felt at peace with her body and became an advocate for body positivity.",
    "She spent years in a toxic workplace, dealing with unfair treatment and constant stress. When she finally found the courage to leave, she discovered a new career path that aligned with her values and gave her more balance in life.",
    "She was afraid of public speaking for years but pushed herself to step out of her comfort zone. Now, she's a successful keynote speaker, inspiring others to overcome their fears and find their own voice.",
    "Having been a stay-at-home mom for years, she feared that re-entering the workforce would be impossible. But after some training and perseverance, she landed her dream job, proving to herself that it was never too late to chase her career goals.",
    "She always felt like an outsider in her family due to her different values and interests. But over time, she learned to embrace her individuality and now uses her unique perspective to create a thriving career in a creative industry.",
    "When her mother passed away, she felt the immense pressure of taking care of her younger siblings. It was difficult, but through love and sacrifice, she helped them through the toughest times, growing into an incredible role model for them.",
    "She spent years hiding her passion for cooking, thinking it was just a hobby. But after receiving rave reviews from friends and family, she took a risk and opened her own restaurant. Today, her business is thriving.",
    "She had always struggled with perfectionism, but after burning out, she learned that embracing imperfection and setting boundaries was key to her happiness. Now, she encourages others to prioritize their mental health over unrealistic standards.",
    "She grew up with a complicated relationship with her father. After years of therapy and self-reflection, she found a way to forgive him, letting go of past hurts and building a healthier relationship.",
    "She found herself in an abusive relationship that took years to escape from. After gaining the courage to leave, she rebuilt her life from the ground up, becoming a fierce advocate for women’s rights and empowerment.",
    "As a first-generation immigrant, she faced constant pressure to succeed and make her parents proud. After achieving her goals, she realized the importance of defining success on her own terms, outside of familial expectations.",
    "After experiencing a traumatic event, she sought out therapy to heal, and over time, turned her pain into purpose by becoming a counselor for others facing similar struggles.",
    "She struggled for years with feelings of inadequacy and comparison, but after focusing on her own journey, she found peace. Today, she runs a blog helping other women embrace their uniqueness and stop comparing themselves to others.",
    "When she lost her job due to company downsizing, she was devastated, but it pushed her to explore her passion for writing. She published her first novel, which became a bestseller, turning an unfortunate event into an exciting new career path.",
    "Having faced financial hardship growing up, she committed herself to becoming financially literate and"
]




addresses = [
    '"City": "Berlin", "Street": "Gneisenaustraße 23", "Neighborhood": "Kreuzberg", "ZIP": "10961", "Country": "Germany"',
    '"City": "Tokyo", "Street": "2-4-7 Akasaka", "Neighborhood": "Minato-ku", "ZIP": "107-0052", "Country": "Japan"',
    '"City": "New York", "Street": "450 Lexington Avenue", "Neighborhood": "Midtown Manhattan", "ZIP": "10163", "Country": "United States"',
    '"City": "Paris", "Street": "19 Rue de la République", "Neighborhood": "Le Marais", "ZIP": "75003", "Country": "France"',
    '"City": "Sydney", "Street": "12 Bondi Road", "Neighborhood": "Bondi Beach", "ZIP": "2026", "Country": "Australia"',
    '"City": "Cape Town", "Street": "15 Church Street", "Neighborhood": "City Bowl", "ZIP": "8001", "Country": "South Africa"',
    '"City": "Rio de Janeiro", "Street": "Rua da Lapa 56", "Neighborhood": "Centro", "ZIP": "20021-000", "Country": "Brazil"',
    '"City": "Moscow", "Street": "Tverskaya Ulitsa 12", "Neighborhood": "Tverskoy", "ZIP": "125047", "Country": "Russia"',
    '"City": "London", "Street": "42 King’s Road", "Neighborhood": "Chelsea", "ZIP": "SW3 4UD", "Country": "United Kingdom"',
    '"City": "Lagos", "Street": "5 Victoria Island", "Neighborhood": "Victoria Island", "ZIP": "100001", "Country": "Nigeria"',
    '"City": "Toronto", "Street": "50 Queen Street West", "Neighborhood": "Downtown", "ZIP": "M5H 2N2", "Country": "Canada"',
    '"City": "Rome", "Street": "Via del Corso 14", "Neighborhood": "Centro Storico", "ZIP": "00186", "Country": "Italy"',
    '"City": "Mumbai", "Street": "123 Marine Drive", "Neighborhood": "Nariman Point", "ZIP": "400021", "Country": "India"',
    '"City": "Los Angeles", "Street": "200 S. Broadway", "Neighborhood": "Downtown LA", "ZIP": "90012", "Country": "United States"',
    '"City": "Istanbul", "Street": "İstiklal Caddesi 101", "Neighborhood": "Beyoğlu", "ZIP": "34421", "Country": "Turkey"',
    '"City": "Seoul", "Street": "45-1, Samseong-dong", "Neighborhood": "Gangnam-gu", "ZIP": "06168", "Country": "South Korea"',
    '"City": "Auckland", "Street": "22 Quay Street", "Neighborhood": "Central Auckland", "ZIP": "1010", "Country": "New Zealand"',
    '"City": "Buenos Aires", "Street": "Av. Corrientes 2400", "Neighborhood": "Balvanera", "ZIP": "C1046AAU", "Country": "Argentina"',
    '"City": "Dubai", "Street": "32 Sheikh Zayed Road", "Neighborhood": "Al Wasl", "ZIP": "00000", "Country": "UAE"',
    '"City": "Cairo", "Street": "1 Tahrir Square", "Neighborhood": "Downtown", "ZIP": "11511", "Country": "Egypt"',
    '"City": "Berlin", "Street": "Prenzlauer Allee 45", "Neighborhood": "Prenzlauer Berg", "ZIP": "10405", "Country": "Germany"',
    '"City": "Los Angeles", "Street": "1010 Wilshire Blvd", "Neighborhood": "Mid-Wilshire", "ZIP": "90017", "Country": "United States"',
    '"City": "Madrid", "Street": "Calle Gran Vía 10", "Neighborhood": "Centro", "ZIP": "28013", "Country": "Spain"',
    '"City": "Barcelona", "Street": "Carrer de Pau Claris 33", "Neighborhood": "Eixample", "ZIP": "08010", "Country": "Spain"',
    '"City": "Rome", "Street": "Viale Trastevere 56", "Neighborhood": "Trastevere", "ZIP": "00153", "Country": "Italy"',
    '"City": "Paris", "Street": "Avenue Montaigne 12", "Neighborhood": "Champs-Élysées", "ZIP": "75008", "Country": "France"',
    '"City": "Tokyo", "Street": "Shibuya 1-2-3", "Neighborhood": "Shibuya", "ZIP": "150-0002", "Country": "Japan"',
    '"City": "New York", "Street": "177 Bleecker Street", "Neighborhood": "Greenwich Village", "ZIP": "10012", "Country": "United States"',
    '"City": "Singapore", "Street": "Orchard Road 205", "Neighborhood": "Orchard", "ZIP": "238854", "Country": "Singapore"',
    '"City": "Berlin", "Street": "Berliner Straße 47", "Neighborhood": "Charlottenburg", "ZIP": "10713", "Country": "Germany"',
    '"City": "San Francisco", "Street": "Pier 39", "Neighborhood": "Fisherman\'s Wharf", "ZIP": "94133", "Country": "United States"',
    '"City": "Sydney", "Street": "5 Macquarie Street", "Neighborhood": "Circular Quay", "ZIP": "2000", "Country": "Australia"',
    '"City": "Hong Kong", "Street": "Nathan Road 20", "Neighborhood": "Tsim Sha Tsui", "ZIP": "000000", "Country": "China"',
    '"City": "Cape Town", "Street": "V&A Waterfront 42", "Neighborhood": "Waterfront", "ZIP": "8002", "Country": "South Africa"',
    '"City": "Buenos Aires", "Street": "Calle Florida 432", "Neighborhood": "Microcentro", "ZIP": "C1005AAH", "Country": "Argentina"',
    '"City": "Moscow", "Street": "Arbat Street 16", "Neighborhood": "Arbat", "ZIP": "119019", "Country": "Russia"',
    '"City": "Lagos", "Street": "Adeniyi Jones Avenue", "Neighborhood": "Ikeja", "ZIP": "100001", "Country": "Nigeria"',
    '"City": "Toronto", "Street": "100 Bloor Street West", "Neighborhood": "Yorkville", "ZIP": "M5S 2Z7", "Country": "Canada"',
    '"City": "Mumbai", "Street": "Juhu Tara Road 110", "Neighborhood": "Juhu", "ZIP": "400049", "Country": "India"',
    '"City": "Rio de Janeiro", "Street": "Avenida Atlântica 2000", "Neighborhood": "Copacabana", "ZIP": "22021-001", "Country": "Brazil"',
    '"City": "Cairo", "Street": "Al Haram 32", "Neighborhood": "Giza", "ZIP": "12611", "Country": "Egypt"',
    '"City": "Dubai", "Street": "Dubai Marina 301", "Neighborhood": "Dubai Marina", "ZIP": "000000", "Country": "UAE"',
    '"City": "Lagos", "Street": "Olu Holloway Road", "Neighborhood": "Ikoyi", "ZIP": "100001", "Country": "Nigeria"',
    '"City": "Seoul", "Street": "Hongdae 25", "Neighborhood": "Mapo-gu", "ZIP": "04007", "Country": "South Korea"',
    '"City": "London", "Street": "1 Oxford Street", "Neighborhood": "West End", "ZIP": "W1D 2ES", "Country": "United Kingdom"',
    '"City": "Moscow", "Street": "Leninsky Prospekt 88", "Neighborhood": "Khamovniki", "ZIP": "119021", "Country": "Russia"',
    '"City": "Auckland", "Street": "9 Queen Street", "Neighborhood": "Auckland Central", "ZIP": "1010", "Country": "New Zealand"',
    '"City": "Tokyo", "Street": "Shinjuku 3-4-5", "Neighborhood": "Shinjuku", "ZIP": "160-0022", "Country": "Japan"',
    '"City": "Paris", "Street": "Boulevard Haussmann 24", "Neighborhood": "Opéra", "ZIP": "75009", "Country": "France"',
]



def Generate():
    Age = random.randint(19, 40)

    Name = random.choice(Male_Name) if random.random() < 0.5 else random.choice(Female_Names)
    Hobby = random.choice(hobbies)
    age = Age
    bio = f"""Name: {Name} 👑
Age: {age} 
Hobby: {Hobby} 🏀"""


    Address = random.choice(addresses)

    if Name in Male_Name:
        Life_story = random.choice(life_stories_man)
    else:
        Life_story = random.choice(life_stories_women)

    

    if Name in Female_Names:
        sex = 'Female'
    else:
       sex = 'MaLe'
    
    if Age < 23:
        Life_story = ''
    else:
        pass

    text_sex = tk.Text(root, height=1, width=30, bg="#000000", fg='red')
    text_sex.insert(1.0, f'Sex: {sex}')
    text_sex.config(state=tk.DISABLED)
    text_sex.place(x=100, y=250)

    txt_name = tk.Text(root, height=1, width=30, bg="#000000", fg='red')
    txt_name.insert(1.0, f'Name: {Name}')
    txt_name.config(state=tk.DISABLED) 
    txt_name.place(x=100, y=300)

    txt_age = tk.Text(root, height=1, width=30, bg="#000000", fg='red')
    txt_age.insert(1.0, f'Age: {age}')
    txt_age.config(state=tk.DISABLED) 
    txt_age.place(x=100, y=350)

    txt_hobby = tk.Text(root, height=4, width=60, bg="#000000", fg='red')
    txt_hobby.insert(1.0, f'Hobby: {Hobby}')
    txt_hobby.config(state=tk.DISABLED)  
    txt_hobby.place(x=100, y=400)
    
    text_about_life = tk.Text(root, height=8, width=80, bg="#000000", fg='red')
    text_about_life.insert(1.0, f'Life Story: {Life_story}')
    text_about_life.config(state=tk.DISABLED)
    text_about_life.place(x=100, y=500)

    address_lbl = tk.Text(root, height=2, width=100, bg="#000000", fg='red')
    address_lbl.insert(1.0, f'Address: {Address}')
    address_lbl.config(state=tk.DISABLED)
    address_lbl.place(x=100, y=700)
    
    bio_lbl = tk.Text(root, height=6, width=100, bg="#000000", fg='red')
    bio_lbl.insert(1.0, f'Bio: {bio}')
    bio_lbl.config(state=tk.DISABLED)
    bio_lbl.place(y=250, x=1000)
def password():
    root.destroy()


Email = tk.Label(root, text='Good Email provider for privacy: protonmail.com', bg="#000000", fg='red',font=('Arial', 16))
Email.place(x=500, y=950)

identity_gen_btn = tk.Button(root, text='Generate', command=Generate, bg="#000000", fg="red", cursor='hand2')
identity_gen_btn.place(x=100, y=900)

Password_gen_site_btn = tk.Button(root, text='Go to password generator', bg="#000000", fg="red", command=password, cursor='hand2')
Password_gen_site_btn.place(x=100, y=950)




Ext_btn = tk.Button(root, text='Exit', bg='black', fg='red', command=root.destroy, cursor='hand2')
Ext_btn.place(x=1800, y=50)


root.mainloop()




# Passsword Generator




sec = tk.Tk()
sec.configure(bg='black')
sec.attributes('-fullscreen', True)


head = tk.Label(sec, text='Password Generator/Checker', bg='black', fg='red', font=('Arial', 24))
head.pack(pady=20)

length_Label = tk.Label(sec, text='Enter the lenght you want for the password (max 20 char):', bg='black', fg='red')
length_Label.place(x=100, y=100)


entry = tk.Entry(sec, bg='black', fg='white', width=50)
entry.place(x=100, y=120)



def generate_pass():
    chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!@#$%^&*()_+{}|:\"<>?~`-=[]\\;',./"

    result = ''.join(random.choice(chars) for i in range(int(entry.get())))

    password = tk.Label(sec, text=f'Generated Password: {result}', bg='black', fg='red')
    password.place(x=100, y=150)


    password = tk.Text(sec, height=1, width=37, bg='black', fg='red')
    password.insert(1.0, f'Password: {result}')
    password.config(state=tk.DISABLED)
    password.place(x=100, y=150)

    if result.__len__() > 20:
        sec.quit()
    
    else:
        pass

gen_btn = tk.Button(sec, text='Generate', bg='black', fg='red', command=generate_pass, cursor='hand2')
gen_btn.place(x=100, y=200)



# Hash Generator

# Sha256
hash256_lbl = tk.Label(sec, text='Enter password to Hash (SHA256):', bg='black', fg='red')
hash256_lbl.place(x=300, y=480)


hash_entry = tk.Entry(sec, bg='black', fg='white', width=50)
hash_entry.place(x=300, y=500)


def hash_psw():
    hash = hashlib.sha256(hash_entry.get().encode()).hexdigest()


    hash256_result = tk.Text(sec, height=1, width=73, bg='black', fg='red')
    hash256_result.insert(1.0, f'Hash: {hash}')
    hash256_result.config(state=tk.DISABLED)
    hash256_result.place(x=300, y=530)

hash256_btn = tk.Button(sec, text='Hash password', bg='black', fg='red', command=hash_psw, cursor='hand2')
hash256_btn.place(x=300, y=560)

# MD5

hash_md5_lbl = tk.Label(sec, text='Enter password to Hash (MD5):', bg='black', fg='red')
hash_md5_lbl.place(x=900, y=480)

hash_md5_entry = tk.Entry(sec, bg='black', fg='white', width=50)
hash_md5_entry.place(x=900, y=500)

def hash_md5():
    hash_md5 = hashlib.md5(hash_md5_entry.get().encode()).hexdigest()


    hash_md5_result = tk.Text(sec, height=1, width=48, bg='black', fg='red')
    hash_md5_result.insert(1.0, f'Hash: {hash_md5}')
    hash_md5_result.config(state=tk.DISABLED)
    hash_md5_result.place(x=900, y=530)

hash_md5_btn = tk.Button(sec, text='Hash password', bg='black', fg='red', command=hash_md5, cursor='hand2')
hash_md5_btn.place(x=900, y=560)

#Github link and exit

link_btn = tk.Button(sec, text='Click here to visit my github', bg='black', fg='red', command=github_link, width=50, height=5, cursor='hand2')

link_btn.place(x=700, y=950)
def exit():
    sec.destroy()


exit_btn = tk.Button(sec, text='Exit', bg='black', fg='red', command=exit, cursor='hand2')
exit_btn.place(x=1800, y=50)


sec.mainloop()


inp = input('Do you like the tool? (yes/no): ')

if inp.lower() == 'yes':
    print('Please give the tool a star on github! Thank you for your support!')
    time.sleep(3)
    webbrowser.open('https://github.com/Glitch1-cyber')
else:
    print('Thank you for using the tool!')