import os
import time

moons = [
    ("Full Moon", "🌕"),
    ("Waning Gibbous", "🌖"),
    ("Last Quarter", "🌗"),
    ("Waning Crescent", "🌘"),
    ("New Moon", "🌑"),
    ("Waxing Crescent", "🌒"),
    ("First Quarter", "🌓"),
    ("Waxing Gibbous", "🌔")
]

def show_moons():
    for name, emoji in moons:
        os.system('cls' if os.name == 'nt' else 'clear')  # Terminal leeren
        print(f"Moon Phase: {name} {emoji}")              # Mond anzeigen
        time.sleep(0.5)                                     # 1 Sekunde warten

show_moons()
